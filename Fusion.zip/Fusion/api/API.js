// const mongoose = require("mongoose");
const UserSchema = require("../models/Incubetee");
const AdminSchema = require("../models/Admin");
const express = require("express");
const bcryptjs = require("bcryptjs")

const Router = express();


// Registration for the user
Router.route('/register')
    .post(async (req, res) => {
        const hashPassword = await bcrypt.hash(req.body.password, 10);
        const data = {
            groupName: req.body.groupName,
            // numberTeamMembers: req.body.numberTeamMembers,
            // nameTeamMembers: req.body.nameTeamMembers,
            authorizationStatus: false,
            deadline: req.body.deadline,
            leaderMailId: req.body.leaderMailId,
            password: hashPassword,
            deadlineStatus: false,
            role: "User"
        }
        console.log(data);
        const user = new UserSchema(data);
        user.save();
        return res.status(200).json(user);
    })

exports = module.exports = Router;