const mongoose = require("mongoose");

const IncubeteeSchema = new mongoose.Schema({
    groupName: String,
    // numberTeamMembers: Number,
    // nameTeamMembers: Array,
    authorizationStatus: {
        Boolean,
        // default: false
    },
    deadline: String,
    leaderMailId: String,
    password: String,
    deadlineStatus: {
        Boolean,
        // default: false
    },
    role: {
        String,
        // default: "User"
    }
});

module.exports = mongoose.model('IncubeteeDetail', IncubeteeSchema);