const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://Fusion:Welcome@123@cluster0.6kipl.mongodb.net/FusionProject?retryWrites=true&w=majority', {
    useUnifiedTopology: true,
    useNewUrlParser: true
}, (err) => {
    if (!err) {
        console.log("Mongodb connected");
    } else {
        console.log("Mongodb is not connected");
    }
});

require("./Admin");
require("./Incubetee")