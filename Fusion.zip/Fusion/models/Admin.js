const mongoose = require("mongoose");

const AdminSchema = new mongoose.Schema({
    adminName: String,
    role: {
        String,
        // default: "Admin"
    },
    mail_id: String,
    password: String
});

module.exports = mongoose.model('AdminDetail', AdminSchema);