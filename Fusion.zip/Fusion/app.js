
const express = require("express");
const bodyParser = require("body-parser");
const apiRoute = require("./api/API");

require("./models/DB");
const app = express();
app.use(bodyParser.urlencoded({extended: true}));
app.use("./api", apiRoute);
app.use(bodyParser.json());


app.listen(8080, function() {
    console.log("Server running at 8080");
})